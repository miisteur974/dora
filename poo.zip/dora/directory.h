﻿#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "file.h"

class directory
{
public:
	directory(std::string name);
	void listFile();
	void back();

protected:
	int dirSize = 2;
	std::string dirPath;
	std::vector<file> fileList;
	std::
};