﻿#pragma once
#include <iostream>
#include <string>
#include <vector>

class date
{
protected:
	unsigned char day;
	unsigned char month;
	int year;
	std::vector<std::string> dayTab = { "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche" };
	std::vector<std::string> monthTab = {
		"Janvier",
		"Février",
		"Mars",
		"Avril",
		"Mai",
		"Juin",
		"Juillet",
		"Aout",
		"Septembre",
		"Octobre",
		"Novembre",
		"Décembre"
	};

public:
	date(int timestamp);
	date(unsigned char day, unsigned char month, int year);


};
