﻿#pragma once

class file
{
public:
	
};
