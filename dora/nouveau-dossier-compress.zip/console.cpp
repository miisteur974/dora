﻿#include "console.h"

console::console()
{
	this->m_root = new directory("C:");
	this->m_cur = this->m_root;
	this->PATH += this->m_cur->get_name() + "/";
}

console::console(directory* root)
{
	this->m_root = root;
	this->m_cur = this->m_root;

	this->PATH += this->m_cur->get_name() + "/";
}

console::~console()
{
	delete this->m_root;
}

bool console::command(std::string input)
{
	std::vector<std::string> args = utils::split(input, ' ');

	if (args[0] == "ls")
		this->ls();
	else if (args[0] == "mkdir")
	{
		unsigned int i = 1;
		while (args[i].empty())
		{
			i++;
		}
		this->mkdir(args[i]);
	}
	else if (args[0] == "touch")
	{
		unsigned int i = 1;
		while (args[i].empty())
		{
			i++;
		}
		this->touch(args[i]);
	}
	else if (args[0] == "pwd")
	{
		std::cout << " " << PATH << std::endl;
	}
	else if (args[0] == "rm")
	{
		unsigned int i = 1;
		while (args[i].empty())
		{
			i++;
		}
		this->rm(args[i]);
	}
	else if (args[0] == "rmdir")
	{

	}
	else if (args[0] == "cd")
	{
		unsigned int i = 1;
		while (args[i].empty())
		{
			i++;
		}
		this->m_cur->add_file(args[i]);
	}
	else if (args[0] == "quit")
	{
		this->logout = true;
	}
	else if (args[0].empty())
	{}
	else
	{
		std::cout << " La commmande \"" << args[0] << "\" n'existe pas ! " << std::endl;
	}
}

bool console::ls()
{
	return true;
}

bool console::mkdir(std::string name)
{
	return true;
}

bool console::touch(std::string name, ullong size)
{
	return true;
}

bool console::pwd()
{
	return true;
}

bool console::rm(std::string path)
{
	return true;
}

bool console::rmdir(std::string path)
{
	return true;
}

bool console::cd(std::string path)
{
	return true;
}

bool console::quit()
{
	return true;
}

directory* console::get_root()
{
	return this->m_root;
}

directory* console::get_cur()
{
	return this->m_cur;
}

std::string console::get_path()
{
	return this->PATH;
}

bool console::isLogout()
{
	return this->logout;
}
