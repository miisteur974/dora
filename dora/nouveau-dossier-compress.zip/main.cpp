#include <iostream> 
#include "directory.h"
#include "console.h"

int main(int argc, char* argv[])
{
	file test("bonjour");
	file test2("Nom.txt");
	directory* root = new directory("C:");
	system("cls");
	console t(root);
	std::string command;
	while (!t.isLogout())
	{
		std::cout << " root@thefakepc:" << t.get_path() << " > ";
		std::getline(std::cin, command);
		t.command(command);
		command.clear();
	}
	system("pause");
	return 0;
}
