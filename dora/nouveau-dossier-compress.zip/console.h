﻿#pragma once
#include <iostream>
#include <string>
#include <vector>
#include "directory.h"

class console
{
protected:
	directory*		m_root;
	directory*		m_cur;
	std::string		PATH;
	bool			logout = false;
public:
	console();
	console(directory* root);
	~console();
	
	bool		command(std::string input);
	bool		ls();
	bool		mkdir(std::string name);
	bool		touch(std::string name, ullong size = 0);
	bool		pwd();
	bool		rm(std::string path);
	bool		rmdir(std::string path);
	bool		cd(std::string path);
	bool		quit();

	directory*	get_root();
	directory*	get_cur();
	std::string get_path();
	bool		isLogout();
};
