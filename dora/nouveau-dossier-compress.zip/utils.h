#pragma once
#include <iostream>
#include <string>
#include <vector>

class utils
{
public:
	static std::vector<std::string> split(std::string a, char limiter);

};