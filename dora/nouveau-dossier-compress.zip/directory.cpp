#include "directory.h"

directory::directory()
{
	this->m_name = "";
	this->m_size = 0;
}

directory::directory(std::string name, file* f)
{
	this->m_name = name;
	if (f)
	{
		f->set_parent(this);
		this->content.push_back(f);
		this->m_size += f->get_size();
	}
}

directory::directory(directory& original)
	: file(original)
{
	this->content = original.get_content();
}

directory::~directory()
{
	for (unsigned int i = 0; i < this->content.size(); i++)
	{
		delete this->content[i];
	}
}

std::vector<file*> directory::get_content() const
{
	return this->content;
}

file* directory::find(std::string name)
{
	std::vector<file*>::iterator it;
	for (it = this->content.begin(); it != this->content.end(); ++it)
	{
		if (((*it)->get_name() == name) || ((*it)->get_fullname() == name))
		{
			return *it;
		}
	}
	return nullptr;
}

bool directory::add_file(std::string name, ullong size)
{
	file *fichier = new file(name, size);
	this->content.push_back(fichier);
	fichier->set_parent(this);
	this->m_size += size;
	return true;
}

bool directory::add_file(file* fil)
{
	if (!fil)
		return false;
	this->content.push_back(fil);
	fil->set_parent(this);
	this->m_size += fil->get_size();
	return true;
}

bool directory::add_dir(std::string name)
{
	directory* dir = new directory(name);
	this->content.push_back(dir);
	dir->set_parent(this);
	return true;
}

bool directory::add_dir(directory* dir)
{
	this->content.push_back(dir);
	dir->set_parent(this);
	return true;
}
