#include "utils.h"

std::vector<std::string> utils::split(std::string a, char limiter)
{
	std::vector<std::string> tab;
	if (a.size() <= 1)
	{
		tab.push_back(a);
		return tab;
	}
	unsigned i = 0, count = 0;
	for (i = 0; i < a.size(); i++)
	{
		if ( a[i] == limiter)
		{
			count++;
		}
	}
	if (count < 1)
	{
		tab.push_back(a);
		return tab;
	} 
	else
	{
		tab.emplace_back();
		count = 0;
		for (i = 0; i < a.size(); i++)
		{
			if ( a[i] != limiter)
			{
				tab[count] += a[i];
			}
			else
			{
				count++;
				tab.emplace_back();
			}
		}
	}
	return tab;
}
