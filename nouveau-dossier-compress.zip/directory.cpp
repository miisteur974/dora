#include "directory.h"

directory::directory()
{
	this->isDefined = false;
	this->isFile = false;
	this->ext = "";
	this->size = 0;

}

directory::directory(std::string name)
{
	this->isDefined = true;
	this->isFile = false;
	this->name = name;
	this->size = 0;
}

directory::directory(std::string dir_name, file& fichier)
{
	this->isDefined = true;
	this->isFile = false;
	this->name = dir_name;
	this->content.push_back(fichier);
	this->size = fichier.get_size();
}

std::string directory::get_name() const
{
	return this->name;
}

bool directory::add_file(std::string name, unsigned int size)
{
	if (name == "")
		return false;
	file newFile = file(name, size);
	this->content.push_back(newFile);
	this->size += newFile.get_size();
	return true;
}

bool directory::add_file(file &f)
{
	if (!f.get_is_defined())
		return false;
	this->content.push_back(f);
	this->size += f.get_size();
	false;
}

std::vector<file> directory::get_content() const
{
	return this->content;
}






