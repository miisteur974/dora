#pragma once
#include <string>
#include <iostream>
#include <vector>

class file
{
public:
	file();
	file(std::string name, unsigned int size);
	virtual ~file();

	// GETTERS 
	virtual std::string get_name() const;
	virtual unsigned int get_size() const;
	virtual bool get_is_defined() const;
	virtual bool get_is_file() const;
	// SETTERS
	virtual bool set_size(unsigned int size);
	virtual bool set_name(std::string name);

protected:

	bool isDefined;
	bool isFile;
	std::string name;
	unsigned int size = 0;
	std::string ext;
};
