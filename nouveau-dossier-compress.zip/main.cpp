#include <iostream> 
#include "directory.h"

int main(int argc, char* argv[])
{
	file test("Bonjour.jpg", 365565);
	directory parent("Dossier1", test);
	std::cout << parent.get_name() << " -->" << parent.get_size() << " : [ 0 ] - " << parent.get_content()[0].get_name() << std::endl;
	system("pause");
	return 0;
}
