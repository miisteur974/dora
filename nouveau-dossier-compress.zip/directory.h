#pragma once
#include "file.h"

class directory : public file
{
public:
	directory();
	directory(std::string name);
	directory::directory(std::string dir_name, file& fichier);
	std::string get_name() const;
	bool add_file(std::string name, unsigned int size);
	bool add_file(file &f);
	std::vector<file> get_content() const;
protected:
	std::vector<file> content;
};