#include "file.h"

file::file()
{
	this->isDefined = false;
	this->isFile = true;
}

file::file(std::string name, unsigned int size)
{

	this->name = name;
	this->size = size;
	this->isFile = true;
	this->isDefined = true;
	int i = 0;

	while (this->name[i] != '.' && i < this->name.size())
	{
		i++;
	}
	if (i == 0)
		this->ext = '\0';
	else
	{
		i++;
		while (i < this->name.size())
		{
			this->ext.push_back(this->name[i]);
			i++;
		}
	}
}

file::~file()
{
	std::cout << this->name << "." << this->ext << " has been deleted " << std::endl;
}

std::string file::get_name() const
{
	return this->name;
}

unsigned file::get_size() const
{
	return this->size;
}

bool file::get_is_defined() const
{
	return this->isDefined;
}

bool file::get_is_file() const
{
	return this->isFile;
}

bool file::set_size(unsigned int size)
{
	this->size = size;
	return true;
}

bool file::set_name(std::string name)
{
	this->name = name;
	int i = 0;

	while (this->name[i] != '.' && i < this->name.size())
	{
		i++;
	}
	if (i == 0)
		this->ext = '\0';
	else
	{
		i++;
		while (i < this->name.size())
		{
			this->ext.push_back(this->name[i]);
			i++;
		}
	}
	return true;
}








